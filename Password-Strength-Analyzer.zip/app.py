from flask import Flask, request
from password_checker import check_password

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <h1>Password Strength Analyzer</h1>
    <form action="/check" method="post">
        <input type="password" name="password" placeholder="Enter Password">
        <button type="submit">Check</button>
    </form>
    """

@app.route("/check", methods=["POST"])
def check():
    password = request.form["password"]
    strength, feedback = check_password(password)
    result = "<br>".join(feedback)

    return f"""
    <h2>Password Strength: {strength}</h2>
    <p>{result}</p>
    <a href="/">Try Again</a>
    """

if __name__ == "__main__":
    app.run(debug=True)
