# Password Strength Analyzer

A Flask-based mini project that evaluates password strength using:
- Length
- Uppercase and lowercase letters
- Numbers
- Special characters

## Run

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000
